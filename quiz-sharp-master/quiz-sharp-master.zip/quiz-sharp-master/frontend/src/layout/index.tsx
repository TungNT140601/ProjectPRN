export { default as SimpleLayout } from './SimpleLayout'

export { default as SmallLayout } from './SmallLayout'

export { default as FullLayout } from './FullLayout'