  
export { default as Triangle } from './icon/Triangle.png'

export { default as Star } from './icon/star.png'

export { default as IconBookMark } from './icon/bookmark.png'

export { default as IconCreate } from './icon/create.png'

export { default as IconDelete } from './icon/delete.png'

export { default as IconEditGray } from './icon/edit.png'

export { default as IconEdit } from './icon/edit2.png'

export { default as IconGlobal } from './icon/global.png'

export { default as IconInformation } from './icon/infor.png'

export { default as IconPlus } from './icon/plus.png'

export { default as IconProfile } from './icon/profile.png'

export { default as IconSetting } from './icon/setting.png'

export { default as IconSettingGray } from './icon/setting2.png'

export { default as IconShare } from './icon/share.png'

export { default as IconTime } from './icon/time.png'

export { default as IconMore } from './icon/more.png'

export { default as IconFolder } from './icon/folder.png'

export { default as IconWrite } from './icon/write.png'

export { default as IconTest } from './icon/test.png'

export { default as IconCard } from './icon/card.png'

export { default as IconMultipleChoice } from './icon/multiplechoice.png'

export { default as Avatar } from './avatar.png'

export { default as IconClose } from './icon/closemodal.png'

export { default as Logo } from './logo.png'

export { default as IconDown } from './icon/down-arrow.png'

export { default as IconGlobalGray } from './icon/globaldisable.png'

export { default as IconGoogle } from './icon/google-plus.png'

export { default as IconFacebook } from './icon/facebook.png'

export { default as IconTwitter } from './icon/twitter.png'

export { default as IconDone } from './icon/done.png'

export { default as IconCancel } from './icon/cancel.png'
