export default interface SetStudy {
  id: number
  username: string
  avatar_url: string
  title: string
  term: number
  createdDate: any
}
