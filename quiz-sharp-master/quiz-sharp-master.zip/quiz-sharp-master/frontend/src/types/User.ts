export default interface User {
  id: number
  username: string
  password: string
  avatar_url: string
  email: string
  dob: Date
}
